import csv
import os
import datetime
import json

textDirPath = "C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\text"
csvDirPath = "C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\csv"
jsonlDirPath = "C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\jsonl"


def read_data(filename):
    with open(filename, 'r') as f:
        lines = [line.strip() for line in f if line.strip()]
    return lines


def convert_to_csv(output, fileName):
    with open(fileName, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(output[0].keys())
        for row in output:
            writer.writerow(row.values())
    return True


def convert_data(lines):
    output = []
    for i, line in enumerate(lines):
        output_lines = {}
        if i == len(lines)-1:
            break
        output_lines = {
            "prompt": line.strip(),
            "completion": lines[i+1].strip()
        }
        output.append(output_lines)
    return output


def csv_to_jsonl(csvFilePath, jsonlDir):
    # Create the directory if it does not exist
    if not os.path.exists(jsonlDir):
        os.makedirs(jsonlDir)

    # Create the JSONL filename with timestamp
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    jsonlFilePath = os.path.join(jsonlDir, f"train_file_{timestamp}.jsonl")

    with open(csvFilePath, 'r') as csv_file, open(jsonlFilePath, 'w') as jsonl_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)  # Skip the header row
        for row in csv_reader:
            prompt = row[0] + "\n\n###\n\n"
            completion = " " + row[1] + "\n"
            json_dict = {'prompt': prompt, 'completion': completion}
            json.dump(json_dict, jsonl_file)
            jsonl_file.write('\n')

    return jsonlFilePath


def generate_jsonl_file():
    files = os.listdir(textDirPath)
    if len(files) != 1:
        print("Exactly one file must exist in the directory.")
        exit()

    filePath = os.path.join(textDirPath, files[0])
    data = read_data(filePath)
    output = convert_data(data)

    timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    fileName = "raw_csv_" + timestamp + ".csv"
    csvPath = os.path.join(csvDirPath, fileName)

    convert_to_csv(output, csvPath)
    print("CSV file created successfully at: " + csvPath)

    jsonlPath = csv_to_jsonl(csvPath, jsonlDirPath)
    print("JSONL file created successfully at: " + jsonlPath)

    return jsonlPath
