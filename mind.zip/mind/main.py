import openai
import os
import glob
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

def chatgpt_Model(prompt):
    # Open AI API Key
    openai.api_key = "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"

    # Replace with your prompt
    model_engine = 'davinci:ft-ukg-inc-2023-04-13-15-31-07'

    print(f"Trained model ID: {model_engine}")

    # Set the temperature parameter to control the randomness of generated text
    temperature = 0.1
    # Set the maximum number of tokens in the generated text
    max_tokens = 50
    # Set the top-p parameter to control the diversity of generated text
    top_p = 0.9
    # Set the frequency penalty parameter to discourage repetitive text
    frequency_penalty = 0.5
    # Set the presence penalty parameter to discourage irrelevant text
    presence_penalty = 0.5

    response = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=top_p,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty
    )

    return response.choices[0].text

@app.route('/chat', methods=['POST'])
def chat():
    message = request.form['message']
    message = message.lower()
    # response = "I'm sorry, I don't understand."
    if message == 'hi' or message == 'hello':
        response = 'Hi there!'
    elif message == 'bye' or message == 'bye':
        response = 'Goodbye!'
    else:
        response = str(chatgpt_Model(message))
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)