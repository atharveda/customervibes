import csv
import json
import openai
import time
import os
import datetime
import preparejsonl
import glob

# Set OpenAI API key
openai.api_key = "<Open AI API Key>"
# Set model ID
# Directory location where trained model is stored.
directory_path = r"C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\trained-model"
files = glob.glob(os.path.join(directory_path, "trained_model_*"))
if files:
    latest_file = max(files, key=os.path.getctime)
else:
    latest_file = None

if latest_file is None:
    model_id = "davinci"
else:
    with open(latest_file, 'r') as f:
        model_id = f.readline().strip()

    if not model_id:
        model_id = "davinci"

print(f"Training started with model ID: {model_id}")
# CSV & JSONL file paths
# csv_file_path = 'C:\\Dev\\Code\\Generative AI\\Training GPT Model\\raw-data\\JenkinsMeeting.csv'
# jsonl_file_path = 'C:\\Dev\\Code\\Generative AI\\Training GPT Model\\raw-data\\Jenkins13.jsonl'

# Set the fine tuned model directory path where you want to save the file
trained_directory_path = 'C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\trained-model'

# Generate JSONL file
jsonl_file_path = preparejsonl.generate_jsonl_file()

time.sleep(1)
os.chmod(jsonl_file_path, 0o600)

# Upload file for fine tuning.
upload_response = openai.File.create(
    file=open(jsonl_file_path, "rb"),
    purpose='fine-tune'
)
print('Uploaded File Response:')
print(upload_response)
file_id = upload_response.id
print('File ID:::' + file_id)

# Start fine-tuning
fine_tune_parameters = {
    "model": model_id,
    "training_file": file_id,
    "n_epochs": 10,
    "batch_size": 4,
    "learning_rate_multiplier": 0.2
}

response = openai.FineTune.create(**fine_tune_parameters)
print('Job ID: ' + response.id)

while True:
    response = openai.FineTune.retrieve(response.id)
    if response.fine_tuned_model:
        print("Fine-tuned model is ready!")
        break
    else:
        print(f"Fine-tuning is still {response.status}...")
        time.sleep(3)

trainedModel = response.fine_tuned_model
print('Trained Model::: ' + trainedModel)

# Get the current timestamp
timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
# Set the filename
filename = f"trained_model_{timestamp}.txt"
# Set the full file path
file_path = os.path.join(trained_directory_path, filename)

# Save the trained model ID in a file with timestamp in the filename
with open(file_path, "w") as f:
    f.write(trainedModel)

print(f"Trained model ID saved in file: {file_path}")
