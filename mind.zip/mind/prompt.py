import openai
import os
import glob

# Open AI API Key
openai.api_key = "<OPENAI_API_KEY>"
# Replace with your prompt
prompt = "What is the cost of 10 Advance Scheduling licenses?"

# Directory location where trained model is stored.
directory_path = r"C:\\Dev\\Code\\Generative AI\\GPT-Model\\mind\\trained-model"
latest_file = max(glob.glob(os.path.join(
    directory_path, "trained_model_*")), key=os.path.getctime)

model_engine = ''
with open(latest_file, 'r') as f:
    model_engine = f.readline().strip()

print(f"Trained model ID: {model_engine}")

# Set the temperature parameter to control the randomness of generated text
temperature = 0.1
# Set the maximum number of tokens in the generated text
max_tokens = 50
# Set the top-p parameter to control the diversity of generated text
top_p = 0.9
# Set the frequency penalty parameter to discourage repetitive text
frequency_penalty = 0.5
# Set the presence penalty parameter to discourage irrelevant text
presence_penalty = 0.5

response = openai.Completion.create(
    engine=model_engine,
    prompt=prompt,
    temperature=temperature,
    max_tokens=max_tokens,
    top_p=top_p,
    frequency_penalty=frequency_penalty,
    presence_penalty=presence_penalty
)

print(response.choices[0].text)
